BANSHU KPI - CORRELATED DUMMY DATA 50

Contents:
- 10 departments
- 50 users
- 10 approval matrices
- 50 KPI forms
- 250 KPI points (5 points per form, total weight 100%)
- 20 demo workflow states: 12 fully APPROVED through BOD BEI, plus intermediate stages

Import order:
1. Departments
2. Users
3. Approval Matrix
4. KPI Forms
5. KPI Points
6. Demo Approval Status

Default password: DemoPass123!

Important:
- Run migration supabase/migrations/0007_demo_approval_seed.sql before importing Demo Approval Status.
- Demo Approval Status only accepts DEMO-KPI-* forms.
- Use only on staging/demo.
